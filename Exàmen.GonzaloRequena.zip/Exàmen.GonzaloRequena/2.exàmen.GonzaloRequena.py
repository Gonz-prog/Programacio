import random # Importem la llibreria per a valors aleatoris

torn=0 # Inici del contador dels torns

# Bucle del joc
while torn<3:
    tirada_IA=random.randrange(0, 3) # Tirada de la màquina entre 0 i 2
    tiraPC=""
    
    # Opcions de l'usuari
    print("1: pedra")
    print("2: paper")
    print("3: tisores")
    
    # Entrada del l'opció
    opcio=int(input("Que tries: "))
    
    #Comprovació de les opcions del jugador
    if opcio == 1:
        tiraJUG = "pedra"
    elif opcio == 2:
        tiraJUG = "paper"
    elif opcio == 3:
        tiraJUG = "tisores"

    # Traducció de les opcions per a vincularles al valor que el PC escollirà
    if tirada_IA == 0:
        tiraPC = "pedra"
    elif tirada_IA == 1:
        tiraPC = "paper"
    elif tirada_IA == 2:
        tiraPC = "tisores"

    # Imprimir la tirada del PC
    print("El PC ha triat",tiraPC)

    # Comprovació de les tirades
    if tiraPC == "pedra" and tiraJUG == "papel":
        torn+=1
        print("Has guanyat, paper envolta la pedra",torn,"torn/s")
    elif tiraPC == "paper" and tiraJUG == "tisores":
        torn+=1
        print("Has guanyat, tisores contra paper",torn,"torn/s")
    elif tiraPC == "tisores" and tiraJUG == "pedra":
        torn+=1
        print("Has guanyat, pedra xafa a les tisores",torn,"torn/s")

    if tiraPC == "paper" and tiraJUG == "pedra":
        torn+=1
        print("Has perdut, paper envolta la pedra",torn,"torn/s")
    elif tiraPC == "tisores" and tiraJUG == "paper":
        torn+=1
        print("Has perdut, les tisores tallen el paper",torn,"torn/s")
    elif tiraPC == "pedra" and tiraJUG == "tisores":
        torn+=1
        print("Has perdut, pedra xafa a les tisores",torn,"torn/s")
    elif tiraPC == tiraJUG:
        torn+=1
        print("Empate en",torn,"torn/s")

    # Fi del programa
    if torn == 3:
        print("Fi del programa")
        break