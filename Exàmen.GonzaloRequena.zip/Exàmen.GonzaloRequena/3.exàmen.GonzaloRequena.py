lista1=["papel", "corcho", "tomate"]
lista2=["tijeras", "mantel"]
lista3=[]
for i in lista1:
    lista3.append(i)
    for j in lista2:
        lista3.append(j)
lista4=set(lista3)
lista4.difference_update()
lista5=list(lista4)
lista5.sort(reverse=True)
print(lista5)