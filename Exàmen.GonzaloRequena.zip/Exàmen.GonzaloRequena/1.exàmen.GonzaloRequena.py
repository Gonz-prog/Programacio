#1
x, y=float(input("\nDigam el valor de x: \n")), float(input("Digam el valor de y: \n"))

word=input("Digam una paraula: \n")

num=int(input("Digam un nombre entre 3 i 7: \n"))
print()

while num >= 3 and num <=7:
    for i in range(num):
        print(word)
    break
else:
    print("ERROR, fi del programa")

resto=x%y
print("\nEl resto de 'x i y':%6.3f"%resto,"\n")